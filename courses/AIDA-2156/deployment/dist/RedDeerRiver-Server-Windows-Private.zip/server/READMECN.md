# Red Deer River 研究数据服务端（Windows）

[English](README.md) · [接口约定](WIRE.md)

**仅限研究。不得用于真实洪水预警、人员疏散、应急处置或安全决策。** 服务使用冻结、不改动的 V4 60/20/20 权重，启动时校验 SHA-256。为避免依赖终点历史来决定上游匹配，实时时效适配器与历史 View 不同；它也没有通过真实洪水验证。P01–P05 是同一组输入下六连网络的未验证中间状态，不是各点独立验证过的传播到达时间或预报。P06 是 05CC002 终点代理水深，并非现场实测水深。终点最新流量只展示，不进入推断。

## 三端如何工作

- **Windows 云服务器**独立运行一个长驻采集器和只读 HTTP API，没有客户端连接也照常抓取 ECCC GeoMet。数据包括 Dickson、小红鹿河、Medicine、Red Deer 四站的流量（05CB007、05CB001、05CC007、05CC002），以及红鹿机场 3025484 小时降雨。
- **云 PostgreSQL 15 及以上**使用单独的数据库与 `rdr_live_v1` 模式。流程为：抓取 → 校验、标准化 → 写入数据库 → 从数据库读取在签发时已具备的记录 → 推断并持久化当前快照。重复、未变观测保留首次获取时间；修订另存。不要把后来获得的数据倒填成早期已知。服务不使用历史项目库的表、View 或原始归档。
- **接收端**只通过 HTTPS 代理读取服务 API，不连接 PostgreSQL；客户端不带数据库凭据、原始归档或权重。服务端压缩包含真实权重，保留为私有，不要通过网站分发。

## 为什么本交付件是 ZIP，不是 Docker

部署目标是普通 Windows x64 虚拟机。私有 ZIP 包含 Python 服务文件、固定的 V4 权重及依赖清单。直接运行无需另装兼容的 Windows 容器运行时，也省掉镜像构建和分发。ZIP 不是自带运行时的安装包：部署人员仍须安装 Python 和列出的依赖，配置 PostgreSQL 连接、后端监听，以及远程客户端所需的 HTTPS。做成容器也仍需各环境的配置及凭据。独立的 AIDA 2154 CV 镜像则封装离线推理依赖，解决的是不同问题。如果以后主机只支持容器，或课程要求容器，可以再为 V4 单独补一份镜像。

## 先在本地运行演示

使用 Windows x64 和 Python 3.13。解压后从 `server/` 的上一级目录运行以下命令，也可使用仓库自带的已验证虚拟环境。

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r server\requirements.txt
.\.venv\Scripts\python.exe -B -m server.service --mode demo --once
.\.venv\Scripts\python.exe -B -m server.service --mode demo --port 8765
```

`--once` 打印一份 JSON 后退出。普通模式启动即抓取，默认每 **600 秒**一轮，可设为 300–3,600 秒。在另一个终端验证：

```powershell
Invoke-RestMethod http://127.0.0.1:8765/healthz
Invoke-RestMethod http://127.0.0.1:8765/api/v1/snapshot
```

演示中观测值是明确标记的合成数据，使用内存存储，不访问 ECCC 或 PostgreSQL；推断走真实冻结权重。合成输入完整时，0 小时、+3 小时和 +9 小时均有数值。演示时刻和数值不代表真实环境观测。

### 本机 PostgreSQL 实时接入流程（`--local-pg`，自动读取 `.env`，不影响云端 TLS 安全）

在自己电脑上用本机 PostgreSQL 运行与云端完全一致的 `rdr_live_v1` 表结构和实时 ECCC GeoMet API 抓取时，加上 **`--local-pg`**（或设 `RDR_ALLOW_LOCAL_PG=1`）即可。未手动设置 `RDR_DEPLOYMENT_DSN` 时，`--local-pg` 会**自动读取仓库根目录（不进 Git）的 `.env` 中的 `PGHOST / PGPORT / PGDATABASE / PGUSER / PGPASSWORD`**（仅允许 `PGHOST` 为 `localhost` / `127.0.0.1`，且只写独立隔离的 `rdr_live_v1` schema，绝不改旧训练表；远端/云端库仍强校验 `sslmode=verify-full` 和 CA 证书）：

```powershell
$env:PYTHONPATH = "$PWD\courses\AIDA-2156\deployment"
# 首次建表只跑一次（仅创建独立 rdr_live_v1 schema）：
.\.venv\Scripts\python.exe -B -m server.service --mode live --local-pg --init-db
# 启动实时 ECCC 抓取与只读 HTTP API（提供 /api/v1/snapshot 和 /api/v1/history48h）：
.\.venv\Scripts\python.exe -B -m server.service --mode live --local-pg --port 8765
```

## 云数据库与服务配置

1. 建立**新的专用 PostgreSQL 15+ 数据库**，限制为私有网络或受限端点，分离迁移账号和运行账号，不连接现有项目库。服务器需可向 `api.weather.gc.ca` 发起 HTTPS，并连接所设 PostgreSQL 的 TCP/TLS 端口；使用同步的系统时钟。
2. 通过安全的服务环境变量注入 **`RDR_DEPLOYMENT_DSN`**：配置 `host=<证书匹配的 DNS 名称>`、`port=<供应商端口>`、`dbname=<专用库>`、`user=<账号>`、必要的密码及 **`sslmode=verify-full`**。在 DSN 写 `sslrootcert=<供应商 CA 文件路径>`，或者设置 **`RDR_DB_SSLROOTCERT`**。必须保留远端证书和主机名校验，不降级到 `require`、`prefer` 或关闭 SSL。不要把凭据写进代码、安装包、任务参数、日志、Git 或客户端。
3. 一次性使用迁移账号运行 `.\.venv\Scripts\python.exe -B -m server.service --mode live --init-db`。只建立版本化模式、`observation_versions`、`current_snapshot` 和索引并退出，不会启动抓取。迁移账号需对新库或专用模式有创建权。运行账号只需 CONNECT、模式 USAGE、观测表 SELECT/INSERT 和快照表 SELECT/INSERT/UPDATE；如果平台单独检查标识序列权限，只授权 `observation_versions_version_id_seq` 的 USAGE。无需给运行账号项目库所有权或云超管权限。
4. 换成运行账号的凭据，可用安全环境配置 **`RDR_API_TOKEN`**（24–256 个符合 Bearer 字符集的字符，建议 URL 安全随机串），启动 `.\.venv\Scripts\python.exe -B -m server.service --mode live`。配置项：`RDR_POLL_SECONDS`（周期）、`RDR_SOURCE_TIMEOUT`（单次请求超时）、`RDR_PORT`（端口）。只允许绑定本机回环地址。日志不会输出 DSN、凭据或鉴权请求头。
5. 其他电脑的接收端使用同 VM 上的 HTTPS 反代地址，配置客户端可验证的证书、访问控制（或 VPN/IP 限制）和限流，建议同时启用后端 Bearer。只转发必要路径，不对外暴露后端端口，不把数据库给客户端。首轮提交前或后端错误时健康接口可返回 HTTP 503。部分站点缺测时 API 仍可展示已有观测，不代表可以给出水深。

## 在哪里修改端口

| 端口 | 修改位置 | 接收端用什么 |
|---|---|---|
| 本机 HTTP 后端（默认 **8765**） | 服务命令加 `--port 8877`，或在服务环境设置 `RDR_PORT=8877`；命令行优先。后端仅绑定 `127.0.0.1`。 | 同机演示填写 `http://127.0.0.1:8877`。远程时把反向代理的上游目标改为 `http://127.0.0.1:8877`；若对外地址不变，客户端无需改。 |
| 对外 HTTPS（通常 **443**） | 修改 Windows 云主机的 HTTPS 反向代理监听端口；代理的上游仍指向真实本机后端端口。远程使用可验证证书和访问控制，不对外暴露后端明文端口。 | 只输入 HTTPS 基础地址，如 443 用 `https://server.example`，8443 用 `https://server.example:8443`。无需重新编译 EXE。 |
| PostgreSQL（供应商指定，常见 **5432**） | 在服务端私有 `RDR_DEPLOYMENT_DSN` 改 `port=...` 并保留 `sslmode=verify-full`。 | 不填。客户端不连数据库。 |

例如运行 `.\.venv\Scripts\python.exe -B -m server.service --mode demo --port 8877`，检查 `http://127.0.0.1:8877/healthz`。改服务端口或数据库设置后须重启服务或 Windows 开机任务；改外部监听端口或代理上游后重载代理。这三个端口彼此独立。客户端只填写基础地址，不附加 `/api/v1/snapshot` 或 `/healthz`。同一个 EXE 使用的 **`/api/v1/snapshot`** 路径与必需字段语义保持稳定；v1 只能向后兼容地增加字段，不兼容时用新 API 版本。正式部署后需从客户端网络实际验证 HTTPS 地址和数据响应；本安装包只做过本机测试，未验证公开远程端点。

## 持续运行、重启与补抓

部署人员可用 Windows 任务计划程序建**唯一**的开机任务。程序为部署虚拟环境的 `python.exe`；参数 `-B -m server.service --mode live`；工作目录为解压后 `server/` 的上一级。用非管理员专用账号，设置无登录也运行，禁止重复实例，进程失败后重启，并确保非交互重启时也能通过安全渠道获得变量。不要在任务参数里写密钥。取消默认短运行时限，设置日志轮转，监控来源新鲜度、最后成功抓取时刻及健康状态。安装包不会自行注册 Windows 服务、改防火墙、开云账号或对外发布。

首次启动和重启补抓最近 **84 小时**；实际上游时段齐全才可估计。正常每轮重叠抓取最近 **3 小时**，部分来源反复失败时在约 12 个失败轮次后尝试更宽窗口，全部源或数据库故障时采用有上限的退避（最长约 30 分钟）。数据库保存最后快照；流量超过 1 小时、降雨从小时结束起超过 3 小时会标过期。超过两个正常轮询周期再加一分钟，缓存的水深估计会隐藏并标不可用。服务不会部署后自动补齐超出近期窗口的停机时段，也不自动删除长期库记录，需运营者配置监控与保留策略。

## 三组水深的含义

- **0 小时**：目标是当前签发 UTC 时刻向下取整到 5 分钟格。Dickson、小红鹿河分别按名义传播 10 小时 30 分和 9 小时取数据库里的上游已知记录；Medicine 按上游早先涨幅确定 30–50 小时 15 分的中心传播时差，另加前后 3 小时的水量分散。小红鹿河缺或 Medicine 候选时段有缺，不出结果。只有 0 小时推断内部可将 Dickson 缺失按零处理并明确记录，界面的实测流量仍为空；按已完成的源小时累计降雨，历史雨量缺测填零仅用于此组。
- **+3 小时**：对未来目标格使用相同权重和路由，前提是签发时所需流量、已结束雨量窗都已收到且可用；不得捏造。结果只用于研究，不是经过真实事件验证的预警提前量。
- **+9 小时**：只有签发时已收到并具备全部所需上游流量和完整降雨窗口才计算。小红鹿河名义传播 9 小时，因此需要当前 5 分钟时间格的实测流量。若该格尚未发布或未抓取到，显示**不可用**。能否推算取决于传播时间和上游数据可用时间，不能用已有记录推知后续流量；未来推算不以填零或沿用上一条流量代替缺测。

本次 Windows 外部测试接收到了 Dickson、Red Deer 流量及较早的机场雨量，然而约 80 小时的 GeoMet 探测中，小红鹿河与 Medicine 没有返回可用记录。只说明本次探测覆盖不足，不代表站点停运或没有水；该时段会正确显示实际缺测和水深不可用。

## 核验范围

本机测试验证了数据时钟、终点流量不影响推断、晚收到的修订不会泄漏、缺测和零分开、过期和故障状态、HTTP/Bearer 授权以及没有客户端时仍可自动轮询。原模型哈希锁定；在独立 Windows PostgreSQL 18.6 临时实例实际验证了模式、历史修订去重、可用时间筛选及重启后的持久性。测试未接触现有项目库或云库，未验证任何实际托管数据库的 TLS 连接、持续在线率或真实洪水可用性。
